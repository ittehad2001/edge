document.getElementById('studentForm').addEventListener('submit', function(event) {
  let valid = true;

  // Validate Student Name
  const studentName = document.getElementById('studentName').value;
  if (!/^[a-zA-Z\s]+$/.test(studentName)) {
      alert('Student Name must contain only letters and spaces.');
      valid = false;
  }

  // Validate Roll Number
  const rollNumber = document.getElementById('rollNumber').value;
  if (!/^\d+$/.test(rollNumber)) {
      alert('Roll Number must be a unique number.');
      valid = false;
  }

  // Validate Mobile
  const mobile = document.getElementById('mobile').value;
  if (!/^\d{10}$/.test(mobile)) {
      alert('Mobile must be a 10-digit number.');
      valid = false;
  }

  // Validate Email
  const email = document.getElementById('email').value;
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
      alert('Email must be a valid email format.');
      valid = false;
  }

  if (!valid) {
      event.preventDefault();
  }
});
