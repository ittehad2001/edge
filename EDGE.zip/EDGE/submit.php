<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "students";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Server-side validation
$studentName = $_POST['studentName'];
$rollNumber = $_POST['rollNumber'];
$mobile = $_POST['mobile'];
$email = $_POST['email'];

$errors = [];

if (!preg_match("/^[a-zA-Z\s]+$/", $studentName)) {
    $errors[] = "Student Name must contain only letters and spaces.";
}

if (!preg_match("/^\d+$/", $rollNumber)) {
    $errors[] = "Roll Number must be a unique number.";
}

if (!preg_match("/^\d{10}$/", $mobile)) {
    $errors[] = "Mobile must be a 10-digit number.";
}

if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    $errors[] = "Email must be a valid email format.";
}

if (empty($errors)) {
    // Check for duplicate roll number or email
    $stmt = $conn->prepare("SELECT * FROM students WHERE roll_number = ? OR email = ?");
    $stmt->bind_param("is", $rollNumber, $email);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        echo "Error: Duplicate roll number or email.";
    } else {
        // Insert data into database
        $stmt = $conn->prepare("INSERT INTO students (student_name, roll_number, mobile, email) VALUES (?, ?, ?, ?)");
        $stmt->bind_param("siss", $studentName, $rollNumber, $mobile, $email);

        if ($stmt->execute()) {
            echo "Success: Data saved successfully.";
        } else {
            echo "Error: " . $stmt->error;
        }
    }

    $stmt->close();
} else {
    foreach ($errors as $error) {
        echo $error . "<br>";
    }
}

$conn->close();
?>
